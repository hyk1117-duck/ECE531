# NanoHTTPD + MongoDB Starter

A minimal website where NanoHTTPD serves both a static frontend and a JSON
REST API, and MongoDB stores the data.

## Structure
```
pom.xml
src/main/java/com/example/Server.java   # web server + REST API
src/main/resources/public/index.html    # frontend (push/pull UI)
```

## Prerequisites
- Java 11+
- Maven
- A running MongoDB instance (local `mongod`, Docker, or a MongoDB Atlas cluster)

## Run it

1. Start MongoDB locally, e.g.:
   ```
   docker run -d -p 27017:27017 --name mongo mongo:latest
   ```
   Or point at Atlas — see the `mongoUri` note in `Server.java`.

2. Build and run:
   ```
   mvn clean package
   java -jar target/nanohttpd-mongo-starter.jar
   ```
   Optional overrides:
   ```
   java -Dport=9090 -DmongoUri="mongodb+srv://user:pass@cluster.mongodb.net" -jar target/nanohttpd-mongo-starter.jar
   ```

3. Open **http://localhost:8080** — the page lets you push new items and pull/delete existing ones.

## API

| Method | Path              | Body                          | Description          |
|--------|-------------------|--------------------------------|-----------------------|
| GET    | `/api/items`       | –                              | list all items        |
| GET    | `/api/items/{id}`  | –                              | get one item          |
| POST   | `/api/items`       | `{"name": "...", "value": "..."}` | create an item     |
| PUT    | `/api/items/{id}`  | `{"name": "...", "value": "..."}` | replace an item    |
| DELETE | `/api/items/{id}`  | –                              | delete an item        |

Test with curl:
```
curl -X POST localhost:8080/api/items -H "Content-Type: application/json" -d '{"name":"temp","value":"72"}'
curl localhost:8080/api/items
```

Every item in a response includes a plain `"id"` string field (converted from MongoDB's
`ObjectId`), e.g.:
```json
{"id": "665f1e2b8c9a4f0012345678", "name": "temp", "value": "72"}
```

## Notes / next steps
- The `items` collection and `mydb` database are created automatically the
  first time you insert a document — no manual setup needed.
- Dependency versions in `pom.xml` are a recent snapshot; check
  [mvnrepository.com](https://mvnrepository.com) for the latest before
  shipping this for real.
- For production: add input validation, auth (e.g. an API key header checked
  in `serve()`), and don't run with a wide-open `Access-Control-Allow-Origin: *`.
- To add more resources (e.g. `/api/users`), duplicate the pattern in
  `serve()` with a second `MongoCollection`.
